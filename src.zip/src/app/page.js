'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { 
  Users, UserCheck, Clock, ShieldAlert, Settings, RefreshCw, 
  Search, CalendarDays, CheckCircle2, LogIn, LogOut, Database,
  LayoutDashboard, Server, AlertTriangle
} from 'lucide-react';
import WeeklyChart from '@/components/WeeklyChart';

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL'); // ALL, WORKING, OUT, ABSENT, LATE
  const [time, setTime] = useState('');

  // Update Clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('ko-KR', { hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Fetch Attendance Data
  const fetchData = async (isSilent = false) => {
    if (!isSilent) setLoading(true);
    else setRefreshing(true);
    
    try {
      const res = await fetch('/api/attendance');
      const json = await res.json();
      if (json.success) {
        setData(json);
      }
    } catch (err) {
      console.error('Failed to fetch attendance data:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Poll for data every 10 seconds
  useEffect(() => {
    fetchData();
    const pollInterval = setInterval(() => {
      fetchData(true);
    }, 10000); // 10 seconds auto-refresh
    
    return () => clearInterval(pollInterval);
  }, []);

  // Filter and search logic for employees
  const filteredEmployees = data?.employeeStatuses?.filter((emp) => {
    // 1. Search Query Filter (name or dept)
    const matchesSearch = 
      emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      emp.dept.toLowerCase().includes(searchQuery.toLowerCase());
      
    // 2. Status Filter
    if (statusFilter === 'ALL') return matchesSearch;
    if (statusFilter === 'WORKING') return matchesSearch && emp.status === '근무중';
    if (statusFilter === 'OUT') return matchesSearch && emp.status === '퇴근';
    if (statusFilter === 'ABSENT') return matchesSearch && emp.status === '미출근';
    if (statusFilter === 'LATE') return matchesSearch && emp.isLate;
    
    return matchesSearch;
  }) || [];

  // Initials logic for Avatar
  const getInitials = (name) => {
    if (!name) return '??';
    if (name.length <= 2) return name;
    return name.substring(name.length - 2);
  };

  const getAvatarColorClass = (empNo) => {
    const num = parseInt(empNo) || 0;
    const colors = ['purple', 'cyan', 'emerald', 'rose', 'amber', 'blue'];
    return colors[num % colors.length];
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F8FAFC] text-[#1E293B]">
        <div className="flex flex-col items-center gap-4">
          <RefreshCw className="h-12 w-12 animate-spin text-[#F26522]" />
          <p className="font-semibold text-lg text-gray-500">데이터를 로드하는 중...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="ga-theme">
      {/* Chart accent configuration override */}
      <style jsx global>{`
        :root {
          --accent-purple: #F26522 !important; /* Make line chart orange */
          --bg-secondary: #0F172A !important;
          --text-primary: #FFFFFF !important;
        }
      `}</style>

      {/* Sidebar */}
      <div className="sidebar">
        <div className="brand">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#FFF0E6] rounded-xl text-[#F26522]">
              <LayoutDashboard className="h-7 w-7" />
            </div>
            <div className="brand-name font-bold text-xl tracking-tight" style={{ background: 'linear-gradient(to right, #F26522, #D84D0E)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              SECOM Manager
            </div>
          </div>
        </div>

        {/* Tab menu */}
        <div className="tab-menu">
          <button className="tab-btn active">
            <LayoutDashboard className="h-4 w-4" />
            실시간 대시보드
          </button>
          
          <Link href="/settings" className="tab-btn decoration-none" style={{ textDecoration: 'none' }}>
            <Settings className="h-4 w-4" />
            시스템 연동 설정
          </Link>
        </div>

        {/* System status details */}
        <div>
          <div className="section-title">📂 시스템 상태</div>
          <div className="file-status-list">
            
            {/* Database Status */}
            <div className="file-item">
              <Database className="h-5 w-5 text-gray-400" />
              <div className="file-info">
                <div className="file-label">세콤 DB 경로</div>
                <div className="file-name" title={data?.dbPath || '경로가 정의되지 않았습니다'}>
                  {data?.dbPath ? data.dbPath.split('\\').pop() : 'DB 비활성화'}
                </div>
              </div>
              <div className={`status-dot ${data?.isDemo ? 'gray' : 'green'}`} title={data?.isDemo ? '데모(Mock) 모드' : '정상 연결됨'} />
            </div>

            {/* Cloud Sync Status */}
            <div className="file-item">
              <Server className="h-5 w-5 text-gray-400" />
              <div className="file-info">
                <div className="file-label">시스템 모드</div>
                <div className="file-name">
                  {data?.mode === 'local' ? '로컬 서버 PC' : '클라우드 DB'}
                </div>
              </div>
              <div className={`status-dot ${data?.isDemo ? 'gray' : 'green'}`} title={data?.isDemo ? '데모(Mock) 모드' : '정상 작동'} />
            </div>

          </div>
        </div>

        {/* Footer/Refresh */}
        <div className="sidebar-footer">
          <button 
            className="btn btn-secondary flex items-center justify-center gap-2" 
            onClick={() => fetchData()}
            disabled={refreshing}
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            수동 업데이트
          </button>
          <div className="text-center text-[11px] text-gray-400 font-semibold mt-2">
            현재 서버 시간: {time}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content">
        
        {/* Connection Error/Demo Banner */}
        {data?.error && (
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3 text-amber-800 shadow-sm animate-slide-up mb-2">
            <AlertTriangle className="h-5 w-5 shrink-0 text-amber-600 mt-0.5" />
            <div>
              <h4 className="font-bold text-sm">연동 경고 알림</h4>
              <p className="text-xs mt-1 text-amber-700 font-semibold">{data.error}</p>
              <Link href="/settings" className="text-xs font-bold text-[#F26522] hover:underline mt-2 inline-block">
                연동 설정 페이지로 이동 &rarr;
              </Link>
            </div>
          </div>
        )}

        {/* Header */}
        <div className="header-panel">
          <div>
            <h1 className="welcome-title">실시간 근태 대시보드</h1>
            <p className="welcome-subtitle">에스원 세콤매니저 데이터베이스 실시간 연동 근태 현황판</p>
          </div>
          <div className="path-badge">
            <span className={`h-2 w-2 rounded-full ${data?.isDemo ? 'bg-amber-500' : 'bg-emerald-500 animate-pulse'}`} />
            <span className="font-semibold">{data?.isDemo ? '데모(Mock) 데이터 모드' : '세콤 실시간 연동 중'}</span>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-4 gap-6">
          
          {/* Stat 1: Total */}
          <div className="card">
            <div className="card-header">
              <div className="card-icon-box">
                <Users className="h-6 w-6" />
              </div>
              <div className="card-title-group">
                <h3 className="card-title">전체 임직원</h3>
                <p className="card-desc">등록된 사원수</p>
              </div>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-[#1E293B]">{data?.stats?.totalEmployees || 0}</span>
              <span className="text-sm font-semibold text-gray-500">명</span>
            </div>
          </div>

          {/* Stat 2: Working Now */}
          <div className="card">
            <div className="card-header">
              <div className="card-icon-box" style={{ backgroundColor: '#E6F4EA', color: '#137333' }}>
                <UserCheck className="h-6 w-6" />
              </div>
              <div className="card-title-group">
                <h3 className="card-title">현재 근무중</h3>
                <p className="card-desc">출근 완료 및 게이트 체류자</p>
              </div>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-[#137333]">{data?.stats?.workingNow || 0}</span>
              <span className="text-sm font-semibold text-gray-500">명</span>
              <span className="ml-auto text-xs font-bold px-2 py-1 bg-emerald-50 text-emerald-700 rounded-full">
                출근율 {data?.stats?.attendanceRate || 0}%
              </span>
            </div>
          </div>

          {/* Stat 3: Late */}
          <div className="card">
            <div className="card-header">
              <div className="card-icon-box" style={{ backgroundColor: '#FEF2F2', color: '#EF4444' }}>
                <Clock className="h-6 w-6" />
              </div>
              <div className="card-title-group">
                <h3 className="card-title">지각 발생</h3>
                <p className="card-desc">9시 초과 출근인원</p>
              </div>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-[#EF4444]">{data?.stats?.late || 0}</span>
              <span className="text-sm font-semibold text-gray-500">명</span>
            </div>
          </div>

          {/* Stat 4: Absent */}
          <div className="card">
            <div className="card-header">
              <div className="card-icon-box" style={{ backgroundColor: '#F1F5F9', color: '#64748B' }}>
                <ShieldAlert className="h-6 w-6" />
              </div>
              <div className="card-title-group">
                <h3 className="card-title">오늘 미출근</h3>
                <p className="card-desc">근태 미출결 상태</p>
              </div>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-[#64748B]">{data?.stats?.absent || 0}</span>
              <span className="text-sm font-semibold text-gray-500">명</span>
            </div>
          </div>

        </div>

        {/* Graphs and Department Summary Rows */}
        <div className="grid grid-cols-3 gap-6">
          
          {/* Weekly Trend Chart */}
          <div className="card col-span-2">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="font-bold text-lg text-gray-800">주간 출근 트렌드</h2>
                <p className="text-xs text-gray-500">최근 7영업일 실시간 출근율 및 출근 인원 추이</p>
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-gray-500">
                <CalendarDays className="h-4 w-4" />
                최근 7일
              </div>
            </div>
            <div className="w-full">
              <WeeklyChart data={data?.weeklyTrend} />
            </div>
          </div>

          {/* Department summary */}
          <div className="card">
            <div className="mb-6">
              <h2 className="font-bold text-lg text-gray-800">부서별 출근 현황</h2>
              <p className="text-xs text-gray-500">부서 단위 근태 진행률 요약</p>
            </div>
            
            <div className="flex flex-col gap-4 overflow-y-auto max-h-[220px] pr-1">
              {data?.deptData?.map((dept, index) => {
                const rate = dept.total > 0 ? Math.round((dept.present / dept.total) * 100) : 0;
                return (
                  <div key={index} className="flex flex-col gap-1.5 pb-3 border-b border-dashed border-gray-100 last:border-0 last:pb-0">
                    <div className="flex justify-between text-xs font-bold">
                      <span className="text-gray-700">{dept.name}</span>
                      <span className="text-gray-500">
                        {dept.present}/{dept.total} 명 ({rate}%)
                      </span>
                    </div>
                    {/* Progress Bar */}
                    <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-[#F26522]" 
                        style={{ width: `${rate}%` }}
                      />
                    </div>
                    {dept.late > 0 && (
                      <span className="text-[10px] font-bold text-red-500 flex items-center gap-1">
                        ⚠ 지각자 {dept.late}명 포함
                      </span>
                    )}
                  </div>
                );
              })}
              {(!data?.deptData || data.deptData.length === 0) && (
                <p className="text-xs text-center text-gray-400 py-6">부서별 데이터가 존재하지 않습니다.</p>
              )}
            </div>
          </div>

        </div>

        {/* Detailed Status Table & Live Feed Grid */}
        <div className="grid grid-cols-3 gap-6">
          
          {/* Employee Status Table Card */}
          <div className="card col-span-2">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between mb-4">
              <div>
                <h2 className="font-bold text-lg text-gray-800">임직원 오늘 근태 현황</h2>
                <p className="text-xs text-gray-500">사원별 출근 및 퇴근 기록과 지각 여부 목록</p>
              </div>
              
              {/* Search Box */}
              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="이름 또는 부서 검색"
                  className="pl-9 pr-4 py-2 text-xs border border-gray-200 rounded-xl outline-none focus:border-[#F26522] focus:ring-1 focus:ring-[#F26522] w-56 font-semibold"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            {/* Filter Tabs */}
            <div className="flex gap-2 border-b border-gray-100 pb-3 mb-4">
              {[
                { id: 'ALL', label: '전체' },
                { id: 'WORKING', label: '근무중' },
                { id: 'OUT', label: '퇴근' },
                { id: 'ABSENT', label: '미출근' },
                { id: 'LATE', label: '지각' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setStatusFilter(tab.id)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                    statusFilter === tab.id
                      ? 'bg-[#FFF0E6] text-[#F26522]'
                      : 'text-gray-500 hover:bg-gray-50'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Table */}
            <div className="overflow-x-auto max-h-[350px] overflow-y-auto pr-1">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-gray-100 text-gray-400 uppercase font-semibold">
                    <th className="pb-3 font-semibold">사원명</th>
                    <th className="pb-3 font-semibold">부서</th>
                    <th className="pb-3 font-semibold">출근시간</th>
                    <th className="pb-3 font-semibold">퇴근시간</th>
                    <th className="pb-3 font-semibold">상태</th>
                    <th className="pb-3 font-semibold">비고</th>
                    <th className="pb-3 font-semibold">최근 게이트</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEmployees.map((emp, index) => (
                    <tr key={index} className="border-b border-gray-50 last:border-0 hover:bg-gray-50/50">
                      <td className="py-3">
                        <div className="flex items-center gap-2">
                          <div className={`avatar ${getAvatarColorClass(emp.empNo)} w-7 h-7 text-[10px] font-bold`}>
                            {getInitials(emp.name)}
                          </div>
                          <span className="font-bold text-[#1E293B]">{emp.name}</span>
                        </div>
                      </td>
                      <td className="py-3 font-semibold text-gray-500">{emp.dept}</td>
                      <td className="py-3 font-mono text-gray-600">{emp.checkIn}</td>
                      <td className="py-3 font-mono text-gray-600">{emp.checkOut}</td>
                      <td className="py-3">
                        <span className={`badge-status ${
                          emp.status === '근무중' ? 'ontime' :
                          emp.status === '퇴근' ? 'none' : 'late'
                        }`}>
                          {emp.status}
                        </span>
                      </td>
                      <td className="py-3">
                        {emp.isLate ? (
                          <span className="px-2 py-0.5 text-[10px] font-bold bg-red-50 text-red-500 border border-red-100 rounded-md">
                            지각 (9시 초과)
                          </span>
                        ) : emp.status === '미출근' ? (
                          <span className="text-gray-300">-</span>
                        ) : (
                          <span className="px-2 py-0.5 text-[10px] font-bold bg-green-50 text-green-600 border border-green-100 rounded-md">
                            정상
                          </span>
                        )}
                      </td>
                      <td className="py-3 text-gray-500 font-semibold">{emp.lastGate}</td>
                    </tr>
                  ))}
                  {filteredEmployees.length === 0 && (
                    <tr>
                      <td colSpan="7" className="py-8 text-center text-gray-400 font-semibold">
                        검색 조건에 맞는 임직원이 없습니다.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Live Feed Recent Logs */}
          <div className="card">
            <div className="mb-4">
              <h2 className="font-bold text-lg text-gray-800">실시간 출입 로그</h2>
              <p className="text-xs text-gray-500">게이트별 최신 출입 이벤트 피드 (최근 15건)</p>
            </div>
            
            <div className="flex flex-col gap-3 overflow-y-auto max-h-[420px] pr-1">
              {data?.recentLogs?.map((log, index) => (
                <div key={index} className="flex gap-3 items-start p-2.5 bg-gray-50/50 hover:bg-gray-50 rounded-xl transition-all border border-gray-100">
                  <div className={`p-1.5 rounded-lg shrink-0 ${
                    log.eventType === '퇴근' 
                      ? 'bg-amber-50 text-amber-600' 
                      : 'bg-blue-50 text-blue-600'
                  }`}>
                    {log.eventType === '퇴근' ? <LogOut className="h-3.5 w-3.5" /> : <LogIn className="h-3.5 w-3.5" />}
                  </div>
                  <div className="flex-grow min-w-0">
                    <div className="flex justify-between items-baseline gap-2">
                      <span className="font-bold text-xs text-[#1E293B] truncate">{log.name}</span>
                      <span className="text-[10px] font-semibold text-gray-400 shrink-0">
                        {log.dateOnly} {log.timeOnly}
                      </span>
                    </div>
                    <p className="text-[10px] text-gray-500 font-semibold truncate mt-0.5">
                      {log.dept} &bull; {log.gateName} &bull; <span className="font-bold text-gray-600">{log.eventType}</span>
                    </p>
                  </div>
                </div>
              ))}
              {(!data?.recentLogs || data.recentLogs.length === 0) && (
                <p className="text-xs text-center text-gray-400 py-12">실시간 기록이 없습니다.</p>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
