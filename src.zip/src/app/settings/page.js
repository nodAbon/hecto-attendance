'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { 
  Settings, Database, Server, RefreshCw, ChevronLeft, Check, 
  AlertCircle, LayoutDashboard, Clock
} from 'lucide-react';

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    appMode: 'local',
    secomDbPath: '',
    databaseUrl: '',
    syncInterval: 60
  });

  const [dbStatus, setDbStatus] = useState({
    dbPath: '',
    isDemo: true,
    mode: 'local'
  });
  
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);
  const [time, setTime] = useState('');

  // Update Clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('ko-KR', { hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Load Settings and Connection Status
  const loadData = async (isSilent = false) => {
    if (!isSilent) setLoading(true);
    else setRefreshing(true);

    try {
      const settingsRes = await fetch('/api/settings');
      const settingsData = await settingsRes.json();
      if (settingsData.success) {
        setSettings(settingsData.settings);
      } else {
        setError('설정을 불러오는 중 오류가 발생했습니다.');
      }

      const attendanceRes = await fetch('/api/attendance');
      const attendanceData = await attendanceRes.json();
      if (attendanceData.success) {
        setDbStatus({
          dbPath: attendanceData.dbPath,
          isDemo: attendanceData.isDemo,
          mode: attendanceData.mode
        });
      }
    } catch (err) {
      setError('API 연결 실패: ' + err.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setSettings(prev => ({
      ...prev,
      [name]: type === 'number' ? parseInt(value, 10) : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);
    setError(null);

    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(settings)
      });
      const data = await res.json();
      
      if (data.success) {
        setSettings(data.settings);
        
        // Fetch the new attendance status to update the sidebar DB status
        try {
          const attendanceRes = await fetch('/api/attendance');
          const attendanceData = await attendanceRes.json();
          if (attendanceData.success) {
            setDbStatus({
              dbPath: attendanceData.dbPath,
              isDemo: attendanceData.isDemo,
              mode: attendanceData.mode
            });
          }
        } catch (attendanceErr) {
          console.error('Failed to update DB status after saving:', attendanceErr);
        }

        if (data.syncResult && !data.syncResult.success) {
          setError(`설정은 저장되었으나 동기화가 실패했습니다: ${data.syncResult.message}`);
        } else {
          setMessage('설정이 저장되었으며 정상적으로 동기화가 설정되었습니다.');
        }
      } else {
        setError(data.error || '설정 저장 중 오류가 발생했습니다.');
      }
    } catch (err) {
      setError('설정 저장 API 요청 실패: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F8FAFC] text-[#1E293B]">
        <div className="flex flex-col items-center gap-4">
          <RefreshCw className="h-12 w-12 animate-spin text-[#F26522]" />
          <p className="font-semibold text-lg text-gray-500">설정을 불러오는 중...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="ga-theme">
      {styleTag}

      {/* Sidebar */}
      <div className="sidebar">
        <div className="brand">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#FFF0E6] rounded-xl text-[#F26522]">
              <LayoutDashboard className="h-7 w-7" />
            </div>
            <div className="brand-name font-bold text-xl tracking-tight" style={{ background: 'linear-gradient(to right, #F26522, #D84D0E)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              SECOM Manager
            </div>
          </div>
        </div>

        {/* Tab menu */}
        <div className="tab-menu">
          <Link href="/" className="tab-btn decoration-none" style={{ textDecoration: 'none' }}>
            <LayoutDashboard className="h-4 w-4" />
            실시간 대시보드
          </Link>
          
          <button className="tab-btn active">
            <Settings className="h-4 w-4" />
            시스템 연동 설정
          </button>
        </div>

        {/* System status details */}
        <div>
          <div className="section-title">📂 시스템 상태</div>
          <div className="file-status-list">
            
            {/* Database Status */}
            <div className="file-item">
              <Database className="h-5 w-5 text-gray-400" />
              <div className="file-info">
                <div className="file-label">세콤 DB 경로</div>
                <div className="file-name" title={dbStatus.dbPath || '경로가 정의되지 않았습니다'}>
                  {dbStatus.dbPath ? dbStatus.dbPath.split('\\').pop() : 'DB 비활성화'}
                </div>
              </div>
              <div className={`status-dot ${dbStatus.isDemo ? 'gray' : 'green'}`} title={dbStatus.isDemo ? '데모(Mock) 모드' : '정상 연결됨'} />
            </div>

            {/* Cloud Sync Status */}
            <div className="file-item">
              <Server className="h-5 w-5 text-gray-400" />
              <div className="file-info">
                <div className="file-label">시스템 모드</div>
                <div className="file-name">
                  {dbStatus.mode === 'local' ? '로컬 서버 PC' : '클라우드 DB'}
                </div>
              </div>
              <div className={`status-dot ${dbStatus.isDemo ? 'gray' : 'green'}`} title={dbStatus.isDemo ? '데모(Mock) 모드' : '정상 작동'} />
            </div>

          </div>
        </div>

        {/* Footer/Refresh */}
        <div className="sidebar-footer">
          <button 
            className="btn btn-secondary flex items-center justify-center gap-2" 
            onClick={() => loadData(true)}
            disabled={refreshing}
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            수동 업데이트
          </button>
          <div className="text-center text-[11px] text-gray-400 font-semibold mt-2">
            현재 서버 시간: {time}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content">
        
        {/* Back Link */}
        <Link href="/" className="back-link">
          <ChevronLeft className="h-4 w-4" /> 대시보드로 돌아가기
        </Link>

        {/* Header */}
        <div className="header-panel">
          <div>
            <h1 className="welcome-title">시스템 연동 설정</h1>
            <p className="welcome-subtitle">세콤매니저 DB 경로 및 외부 클라우드 DB 연동(Vercel 배포용)을 설정합니다.</p>
          </div>
          <div className="path-badge">
            <span className={`h-2 w-2 rounded-full ${dbStatus.isDemo ? 'bg-amber-500' : 'bg-emerald-500 animate-pulse'}`} style={{ display: 'inline-block', borderRadius: '50%', backgroundColor: dbStatus.isDemo ? '#f59e0b' : '#10b981', width: '8px', height: '8px' }} />
            <span className="font-semibold">{dbStatus.isDemo ? '데모(Mock) 데이터 모드' : '세콤 실시간 연동 중'}</span>
          </div>
        </div>

        {/* Form Area */}
        <div className="card settings-card" style={{ maxWidth: '720px', width: '100%', margin: '0' }}>
          
          <div className="card-header">
            <div className="card-icon-box">
              <Settings className="h-6 w-6" />
            </div>
            <div className="card-title-group">
              <h3 className="card-title">연동 상세 설정</h3>
              <p className="card-desc">로컬 및 클라우드 연동에 필요한 세부 설정을 관리합니다.</p>
            </div>
          </div>

          <div className="card-body">
            {/* Message Banners */}
            {message && (
              <div className="banner banner-success">
                <Check className="h-5 w-5 shrink-0 banner-icon" />
                <p className="banner-text">{message}</p>
              </div>
            )}

            {error && (
              <div className="banner banner-error">
                <AlertCircle className="h-5 w-5 shrink-0 banner-icon" />
                <p className="banner-text">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Mode Select */}
              <div className="input-group">
                <label className="input-label">연동 모드 설정 (App Mode)</label>
                <div className="mode-select-grid">
                  <button
                    type="button"
                    onClick={() => setSettings(prev => ({ ...prev, appMode: 'local' }))}
                    className={`mode-select-btn ${settings.appMode === 'local' ? 'active' : ''}`}
                  >
                    <Server className="h-6 w-6" />
                    <div>
                      <div className="btn-title">로컬 모드 (Server PC)</div>
                      <div className="btn-desc">세콤 서버 PC에서 실행 시 선택</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSettings(prev => ({ ...prev, appMode: 'cloud' }))}
                    className={`mode-select-btn ${settings.appMode === 'cloud' ? 'active' : ''}`}
                  >
                    <Database className="h-6 w-6" />
                    <div>
                      <div className="btn-title">클라우드 모드 (Vercel)</div>
                      <div className="btn-desc">Vercel 클라우드 배포 시 선택</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Local DB Path (Only relevant for local mode) */}
              {settings.appMode === 'local' && (
                <div className="input-group">
                  <label htmlFor="secomDbPath" className="input-label">
                    세콤매니저 데이터베이스 폴더 경로
                  </label>
                  <div className="input-desc">
                    `WorkManager.DB` 및 `HRData.DB` 파일이 존재하는 상위 폴더 경로를 입력하세요.
                  </div>
                  <input
                    type="text"
                    id="secomDbPath"
                    name="secomDbPath"
                    value={settings.secomDbPath}
                    onChange={handleChange}
                    placeholder="예: C:\(주)에스원\세콤매니저(근태·식당) v9.0.1\Database"
                    className="form-input"
                    required={settings.appMode === 'local'}
                  />
                </div>
              )}

              {/* Cloud DB Url */}
              <div className="input-group">
                <label htmlFor="databaseUrl" className="input-label">
                  클라우드 데이터베이스 URL (PostgreSQL)
                </label>
                <div className="input-desc">
                  로컬 세콤 데이터를 전송하고, Vercel 대시보드가 읽어올 클라우드 DB 연결 주소(Supabase 등)입니다.
                </div>
                <input
                  type="password"
                  id="databaseUrl"
                  name="databaseUrl"
                  value={settings.databaseUrl}
                  onChange={handleChange}
                  placeholder="postgres://user:password@host:port/dbname"
                  className="form-input"
                />
                {settings.appMode === 'cloud' && !settings.databaseUrl && (
                  <div className="banner banner-warning" style={{ marginTop: '10px', marginBottom: '0' }}>
                    <Check className="h-4 w-4 shrink-0 banner-icon" />
                    <span className="banner-text">클라우드 모드에서는 데이터베이스 URL이 비어있을 경우 데모 데이터(Mock Data)로 화면을 그립니다.</span>
                  </div>
                )}
              </div>

              {/* Sync Interval (Only relevant for local mode) */}
              {settings.appMode === 'local' && (
                <div className="input-group">
                  <label htmlFor="syncInterval" className="input-label">
                    클라우드 동기화 주기 (초)
                  </label>
                  <input
                    type="number"
                    id="syncInterval"
                    name="syncInterval"
                    value={settings.syncInterval}
                    onChange={handleChange}
                    min="10"
                    max="3600"
                    className="form-input"
                    required
                  />
                  <div className="input-desc">
                    로컬 SQLite DB의 변경사항을 클라우드 DB로 업로드하는 시간 간격입니다. (최소 10초)
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="form-actions">
                <button
                  type="submit"
                  disabled={saving}
                  className="btn btn-primary"
                  style={{ flex: 1 }}
                >
                  {saving ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" /> 저장 중...
                    </>
                  ) : (
                    '설정 저장 및 적용'
                  )}
                </button>
                
                <Link href="/" className="btn btn-secondary" style={{ flex: 1, textDecoration: 'none' }}>
                  취소
                </Link>
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

// Styled helper components to avoid Tailwind dependency in custom layouts
const styleTag = (
  <style jsx global>{`
    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: var(--text-sub);
      font-size: 14px;
      font-weight: 600;
      transition: var(--transition);
      text-decoration: none;
      margin-bottom: 16px;
    }
    .back-link:hover {
      color: var(--primary);
    }
    .settings-card:hover {
      transform: none !important;
    }
    .banner {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 16px;
      border-radius: var(--radius-sm);
      font-size: 13px;
      font-weight: 500;
      line-height: 1.5;
      box-shadow: var(--shadow-sm);
      margin-bottom: 24px;
    }
    .banner-success {
      background-color: #ECFDF5;
      border: 1px solid #A7F3D0;
      color: #065F46;
    }
    .banner-error {
      background-color: #FEF2F2;
      border: 1px solid #FEE2E2;
      color: #991B1B;
    }
    .banner-warning {
      background-color: #FFFBEB;
      border: 1px solid #FEF3C7;
      color: #92400E;
    }
    .banner-icon {
      flex-shrink: 0;
      margin-top: 2px;
    }
    .banner-text {
      font-size: 12px;
      font-weight: 600;
      margin: 0;
    }
    .input-group {
      display: flex;
      flex-direction: column;
      margin-bottom: 20px;
    }
    .input-label {
      display: block;
      font-size: 13px;
      font-weight: 700;
      color: var(--text-sub);
      margin-bottom: 6px;
    }
    .input-desc {
      font-size: 12px;
      color: var(--text-sub);
      font-weight: 500;
      margin-top: 2px;
      margin-bottom: 8px;
    }
    .form-input {
      width: 100%;
      height: 44px;
      border-radius: var(--radius-sm);
      border: 1px solid var(--border-color);
      padding: 0 16px;
      font-size: 13.5px;
      font-family: inherit;
      font-weight: 500;
      outline: none;
      background-color: var(--bg);
      transition: var(--transition);
      box-sizing: border-box;
    }
    .form-input:focus {
      border-color: var(--primary) !important;
      box-shadow: 0 0 0 2px var(--primary-glow) !important;
    }
    .mode-select-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
      margin-top: 4px;
    }
    .mode-select-btn {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 12px;
      padding: 20px;
      border-radius: var(--radius-md);
      border: 1px solid var(--border-color);
      background-color: var(--card-bg);
      color: var(--text-sub);
      cursor: pointer;
      transition: var(--transition);
      outline: none;
      text-align: center;
      box-shadow: var(--shadow-sm);
    }
    .mode-select-btn:hover {
      border-color: #CBD5E1;
      background-color: #F8FAFC;
      transform: translateY(-2px);
    }
    .mode-select-btn.active {
      border-color: var(--primary) !important;
      background-color: var(--primary-light) !important;
      color: var(--primary) !important;
      box-shadow: var(--shadow-sm) !important;
    }
    .mode-select-btn.active .btn-desc {
      color: var(--primary) !important;
      opacity: 0.8;
    }
    .mode-select-btn .btn-title {
      font-size: 14px;
      font-weight: 700;
    }
    .mode-select-btn .btn-desc {
      font-size: 11px;
      color: var(--text-sub);
      font-weight: 500;
      margin-top: 4px;
    }
    .form-actions {
      display: flex;
      gap: 16px;
      margin-top: 28px;
      padding-top: 20px;
      border-top: 1px solid var(--border-color);
    }
    .space-y-6 > * + * {
      margin-top: 1.5rem;
    }
  `}</style>
);
