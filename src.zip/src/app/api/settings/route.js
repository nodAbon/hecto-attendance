import { NextResponse } from 'next/server';
import { getSettings, saveSettings } from '@/lib/secomDb';

export async function GET() {
  try {
    const settings = getSettings();
    return NextResponse.json({
      success: true,
      settings
    });
  } catch (err) {
    return NextResponse.json({
      success: false,
      error: err.message
    }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    
    // 설정 저장 (로컬 파일에만 저장, DB 접근 없음)
    const updated = saveSettings(body);

    return NextResponse.json({
      success: true,
      settings: updated
    });
  } catch (err) {
    return NextResponse.json({
      success: false,
      error: err.message
    }, { status: 500 });
  }
}
