import { NextResponse } from 'next/server';
import { fetchAttendanceLogs, getSettings } from '@/lib/secomDb';

export async function GET() {
  try {
    const settings = getSettings();
    const { logs, employees, isDemo, error } = await fetchAttendanceLogs();

    // 1. 전체 직원 목록 기준 설정
    // MySQL 연결 성공 시: hr_employee에서 조회한 재직자 목록 (정확)
    // Fallback 시: 로그에서 추출한 고유 사번 (근사값)
    const allEmployeesMap = new Map();

    if (employees && employees.length > 0) {
      // ✅ 정확한 방식: hr_employee 기준 (로그 유무 무관)
      employees.forEach(emp => {
        allEmployeesMap.set(emp.empNo, {
          empNo: emp.empNo,
          name: emp.name,
          dept: emp.dept,
          cardNo: ''
        });
      });
    } else {
      // fallback: 로그에서 추출
      logs.forEach(log => {
        allEmployeesMap.set(log.empNo, {
          empNo: log.empNo,
          name: log.name,
          dept: log.dept,
          cardNo: log.cardNo
        });
      });
    }

    const totalEmployeesCount = allEmployeesMap.size || 10;

    // 2. 오늘 날짜 기준 로그 필터
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0]; // "YYYY-MM-DD"

    const todayLogs = logs.filter(log => log.logTime.startsWith(todayStr));

    // 오늘 직원별 로그 그룹화
    const empTodayMap = new Map();
    todayLogs.forEach(log => {
      if (!empTodayMap.has(log.empNo)) {
        empTodayMap.set(log.empNo, []);
      }
      empTodayMap.get(log.empNo).push(log);
    });

    const presentEmpNos = new Set(empTodayMap.keys());
    const presentCount = presentEmpNos.size;
    const absentCount = Math.max(0, totalEmployeesCount - presentCount);

    let lateCount = 0;
    let workingNowCount = 0;
    const employeeStatuses = [];

    // 3. 전체 직원 목록 기준으로 오늘 상태 계산
    allEmployeesMap.forEach((emp, empNo) => {
      const empLogs = empTodayMap.get(empNo) || [];

      if (empLogs.length > 0) {
        const sortedLogs = [...empLogs].sort((a, b) => a.logTime.localeCompare(b.logTime));
        const firstLog = sortedLogs[0];
        const lastLog = sortedLogs[sortedLogs.length - 1];

        // 지각 여부: 첫 출입이 09:00 이후면 지각
        const checkInTimeOnly = firstLog.logTime.split(' ')[1]; // "HH:MM:SS"
        const isLate = checkInTimeOnly > '09:00:00';
        if (isLate) lateCount++;

        // 현재 근무 여부: 마지막 이벤트가 퇴근이 아니면 근무중
        const isCheckedOut = lastLog.eventType === '퇴근';
        const status = isCheckedOut ? '퇴근' : '근무중';
        if (status === '근무중') workingNowCount++;

        employeeStatuses.push({
          ...emp,
          status,
          checkIn: firstLog.logTime.split(' ')[1].substring(0, 5), // "HH:MM"
          checkOut: isCheckedOut ? lastLog.logTime.split(' ')[1].substring(0, 5) : '-',
          isLate,
          lastGate: lastLog.gateName
        });
      } else {
        // 로그 없음 = 미출근 (hr_employee에 있지만 오늘 출입 기록 없음)
        employeeStatuses.push({
          ...emp,
          status: '미출근',
          checkIn: '-',
          checkOut: '-',
          isLate: false,
          lastGate: '-'
        });
      }
    });

    // 4. 주간 트렌드 (최근 7일)
    const weeklyTrend = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(now.getDate() - i);
      const dStr = d.toISOString().split('T')[0];
      const dayName = d.toLocaleDateString('ko-KR', { weekday: 'short' });

      const dayEmpNos = new Set(
        logs
          .filter(log => log.logTime.startsWith(dStr))
          .map(log => log.empNo)
      );

      if ((d.getDay() === 0 || d.getDay() === 6) && dayEmpNos.size === 0) continue;

      weeklyTrend.push({
        date: dStr.substring(5, 10).replace('-', '/'),
        dayName,
        count: dayEmpNos.size,
        rate: totalEmployeesCount > 0 ? Math.round((dayEmpNos.size / totalEmployeesCount) * 100) : 0
      });
    }

    // 5. 부서별 분포
    const deptDistribution = {};
    employeeStatuses.forEach(emp => {
      if (!deptDistribution[emp.dept]) {
        deptDistribution[emp.dept] = { total: 0, present: 0, late: 0 };
      }
      deptDistribution[emp.dept].total++;
      if (emp.status !== '미출근') {
        deptDistribution[emp.dept].present++;
        if (emp.isLate) deptDistribution[emp.dept].late++;
      }
    });

    const formattedDeptData = Object.keys(deptDistribution).map(dept => ({
      name: dept,
      total: deptDistribution[dept].total,
      present: deptDistribution[dept].present,
      late: deptDistribution[dept].late
    }));

    return NextResponse.json({
      success: true,
      isDemo,
      error: error || null,
      mode: settings.appMode,
      stats: {
        totalEmployees: totalEmployeesCount,
        present: presentCount,
        absent: absentCount,
        late: lateCount,
        workingNow: workingNowCount,
        attendanceRate: totalEmployeesCount > 0 ? Math.round((presentCount / totalEmployeesCount) * 100) : 0
      },
      weeklyTrend,
      deptData: formattedDeptData,
      employeeStatuses: employeeStatuses.sort((a, b) => {
        const statusPriority = { '근무중': 1, '퇴근': 2, '미출근': 3 };
        return statusPriority[a.status] - statusPriority[b.status] || a.name.localeCompare(b.name);
      }),
      recentLogs: logs.slice(0, 15).map(log => ({
        ...log,
        timeOnly: log.logTime.split(' ')[1].substring(0, 5),
        dateOnly: log.logTime.split(' ')[0].substring(5, 10).replace('-', '/')
      }))
    });

  } catch (err) {
    console.error('API attendance error:', err);
    return NextResponse.json({
      success: false,
      error: err.message
    }, { status: 500 });
  }
}
