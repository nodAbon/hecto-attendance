'use strict';
import React from 'react';

export default function WeeklyChart({ data = [] }) {
  if (!data || data.length === 0) {
    return (
      <div style={{ height: '200px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
        데이터가 없습니다.
      </div>
    );
  }

  const height = 180;
  const width = 500;
  const padding = { top: 20, right: 20, bottom: 30, left: 30 };

  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  // Find max value for Y scaling
  const maxVal = Math.max(...data.map(d => d.count), 5); // Minimum y-axis max is 5
  const yMax = Math.ceil(maxVal / 5) * 5; // Round to nearest 5

  // Map data to x, y coordinates
  const points = data.map((d, index) => {
    const x = padding.left + (index / (data.length - 1)) * chartWidth;
    const y = padding.top + chartHeight - (d.count / yMax) * chartHeight;
    return { x, y, ...d };
  });

  // Create SVG path for line
  let linePath = '';
  let areaPath = '';
  
  if (points.length > 0) {
    // Generate curved line path using cubic bezier or straight lines.
    // Straight lines are easier and clean, but bezier looks premium. Let's do smooth cubic bezier.
    linePath = `M ${points[0].x} ${points[0].y}`;
    areaPath = `M ${points[0].x} ${padding.top + chartHeight} L ${points[0].x} ${points[0].y}`;
    
    for (let i = 1; i < points.length; i++) {
      const prev = points[i - 1];
      const curr = points[i];
      const cpX1 = prev.x + (curr.x - prev.x) / 3;
      const cpY1 = prev.y;
      const cpX2 = prev.x + 2 * (curr.x - prev.x) / 3;
      const cpY2 = curr.y;
      
      linePath += ` C ${cpX1} ${cpY1}, ${cpX2} ${cpY2}, ${curr.x} ${curr.y}`;
      areaPath += ` C ${cpX1} ${cpY1}, ${cpX2} ${cpY2}, ${curr.x} ${curr.y}`;
    }
    
    // Close the area path
    areaPath += ` L ${points[points.length - 1].x} ${padding.top + chartHeight} Z`;
  }

  // Y-axis grid ticks
  const yTicks = [0, 0.25, 0.5, 0.75, 1].map(ratio => Math.round(yMax * ratio));

  return (
    <div style={{ width: '100%', overflowX: 'auto' }}>
      <svg viewBox={`0 0 ${width} ${height}`} width="100%" height={height} style={{ overflow: 'visible' }}>
        <defs>
          {/* Area Gradient */}
          <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--accent-purple)" stopOpacity="0.3" />
            <stop offset="100%" stopColor="var(--accent-purple)" stopOpacity="0.0" />
          </linearGradient>
          {/* Line Glow Filter */}
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Y-Axis Grid Lines */}
        {yTicks.map((tick, i) => {
          const y = padding.top + chartHeight - (tick / yMax) * chartHeight;
          return (
            <g key={i}>
              <line 
                x1={padding.left} 
                y1={y} 
                x2={width - padding.right} 
                y2={y} 
                stroke="rgba(255, 255, 255, 0.05)" 
                strokeWidth="1"
                strokeDasharray="4 4"
              />
              <text 
                x={padding.left - 8} 
                y={y + 4} 
                fill="var(--text-muted)" 
                fontSize="10" 
                textAnchor="end"
                fontFamily="inherit"
              >
                {tick}명
              </text>
            </g>
          );
        })}

        {/* X-Axis Labels */}
        {points.map((pt, i) => (
          <text 
            key={i} 
            x={pt.x} 
            y={height - 8} 
            fill="var(--text-muted)" 
            fontSize="10" 
            textAnchor="middle"
            fontFamily="inherit"
          >
            {pt.date} ({pt.dayName})
          </text>
        ))}

        {/* Gradient Area Fill */}
        {areaPath && (
          <path 
            d={areaPath} 
            fill="url(#chartGradient)" 
          />
        )}

        {/* Curved Path */}
        {linePath && (
          <path 
            d={linePath} 
            fill="none" 
            stroke="var(--accent-purple)" 
            strokeWidth="3"
            filter="url(#glow)"
            style={{ transition: 'all 0.5s ease' }}
          />
        )}

        {/* Points & Hover Indicators */}
        {points.map((pt, i) => (
          <g key={i} className="chart-point-group" style={{ cursor: 'pointer' }}>
            {/* Outer halo */}
            <circle 
              cx={pt.x} 
              cy={pt.y} 
              r="7" 
              fill="rgba(139, 92, 246, 0.2)" 
              opacity="0" 
              style={{ transition: 'opacity 0.2s ease' }}
              className="point-halo"
            />
            {/* Inner dot */}
            <circle 
              cx={pt.x} 
              cy={pt.y} 
              r="4" 
              fill="var(--text-primary)" 
              stroke="var(--accent-purple)" 
              strokeWidth="2" 
            />
            {/* Tooltip on hover */}
            <g className="point-tooltip" style={{ opacity: 0, transition: 'opacity 0.2s ease', pointerEvents: 'none' }}>
              <rect 
                x={pt.x - 45} 
                y={pt.y - 35} 
                width="90" 
                height="22" 
                rx="4" 
                fill="var(--bg-secondary)" 
                stroke="var(--accent-purple)" 
                strokeWidth="1"
              />
              <text 
                x={pt.x} 
                y={pt.y - 20} 
                fill="var(--text-primary)" 
                fontSize="10" 
                fontWeight="600"
                textAnchor="middle"
              >
                출근: {pt.count}명 ({pt.rate}%)
              </text>
            </g>
          </g>
        ))}
      </svg>
      
      {/* Styles for hover effect without Tailwind config */}
      <style jsx>{`
        .chart-point-group:hover .point-halo {
          opacity: 1 !important;
        }
        .chart-point-group:hover .point-tooltip {
          opacity: 1 !important;
        }
      `}</style>
    </div>
  );
}
