/**
 * Secom MySQL Connection & Data Inspector v1.0
 * --------------------------------------------------
 * 이 도구는 서버 PC에서 ODBC DSN에 등록된 Hecto_Live MySQL 데이터베이스에 접속하여
 * 실제로 세콤 근태 로그가 해당 DB에 동기화되고 있는지 확인합니다.
 * 
 * [실행 방법]
 * 1. 이 파일(secom_mysql_check.js)을 세콤 서버 PC로 복사합니다.
 * 2. 서버 PC의 명령 프롬프트(cmd)에서 다음 명령을 실행합니다:
 *    npm install mysql2 (필요한 경우 자동 설치)
 *    node secom_mysql_check.js
 * 3. 출력 결과를 복사하여 전달해주세요.
 */

const fs = require('fs');
const { execSync } = require('child_process');

console.log('==================================================');
console.log(' 세콤 ODBC MySQL 데이터베이스 검증 도구 v1.0');
console.log('==================================================');

// mysql2 라이브러리 검사 및 설치
try {
  require('mysql2');
} catch (e) {
  console.log('[+] mysql2 모듈이 없습니다. 자동으로 설치를 시작합니다...');
  try {
    execSync('npm install mysql2', { stdio: 'inherit' });
    console.log('[+] mysql2 모듈 설치 완료.');
  } catch (err) {
    console.error('[-] mysql2 설치 실패. 인터넷 연결을 확인하거나 npm install mysql2를 수동 실행하세요.', err.message);
    process.exit(1);
  }
}

const mysql = require('mysql2');

const config = {
  host: 'Prd-Hecto-WHR-Ext-NLB-8e82b66ed560637d.elb.ap-northeast-2.amazonaws.com',
  user: 'whradmin',
  password: '1q2w3e4r!@#$',
  database: 'whr',
  port: 3306,
  connectTimeout: 5000
};

console.log(`\n[1] MySQL DB 연결 시도...`);
console.log(`  - 호스트: ${config.host}`);
console.log(`  - 데이터베이스: ${config.database}`);

const connection = mysql.createConnection(config);

connection.connect((err) => {
  if (err) {
    console.error('\n[-] MySQL 연결에 실패했습니다.');
    console.error(`    오류 메시지: ${err.message}`);
    console.log('\n[안내] 방화벽 등으로 인해 DB 서버 접근이 차단되어 있을 수 있습니다.');
    process.exit(1);
  }

  console.log('[+] MySQL 연결 성공!');

  console.log('\n[2] 테이블 목록 조회 중...');
  connection.query('SHOW TABLES', (err, results) => {
    if (err) {
      console.error('[-] 테이블 목록 조회 실패:', err.message);
      connection.end();
      return;
    }

    console.log('    발견된 테이블 목록:');
    results.forEach(row => {
      console.log(`      - ${Object.values(row)[0]}`);
    });

    console.log('\n[3] attendance_logs 테이블 데이터 검사 중...');
    connection.query('SELECT COUNT(*) as count FROM attendance_logs', (err, results) => {
      if (err) {
        console.error('[-] attendance_logs 테이블이 없거나 조회에 실패했습니다:', err.message);
        connection.end();
        return;
      }

      const totalRows = results[0].count;
      console.log(`    - 전체 행(Row) 수: ${totalRows}개`);

      if (totalRows > 0) {
        connection.query('SELECT * FROM attendance_logs ORDER BY log_time DESC LIMIT 3', (err, results) => {
          if (err) {
            console.error('[-] 최근 데이터 조회 실패:', err.message);
          } else {
            console.log('\n    - 최근 동기화된 데이터 3건:');
            results.forEach((row, idx) => {
              console.log(`      [${idx + 1}] 사번: ${row.emp_no || row.sabun}, 이름: ${row.name}, 시간: ${row.log_time}, 구분: ${row.event_type || row.status}`);
            });
            console.log('\n[결론] 이 데이터베이스를 직접 사용하여 대시보드를 연동할 수 있습니다!');
          }
          connection.end();
        });
      } else {
        console.log('\n[결론] 테이블은 존재하나 데이터가 비어 있습니다. 세콤 링크 연동 설정이 안 되어 있는 것 같습니다.');
        connection.end();
      }
    });
  });
});
