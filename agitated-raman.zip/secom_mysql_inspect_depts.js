/**
 * Secom MySQL Department Table Inspector v1.0
 */

const mysql = require('mysql2');

const config = {
  host: 'Prd-Hecto-WHR-Ext-NLB-8e82b66ed560637d.elb.ap-northeast-2.amazonaws.com',
  user: 'whradmin',
  password: '1q2w3e4r!@#$',
  database: 'whr',
  port: 3306,
  connectTimeout: 5000
};

const connection = mysql.createConnection(config);

const TARGET_TABLES = [
  'hr_department',
  'v_hr_department',
  'v_dept',
  'division'
];

connection.connect(async (err) => {
  if (err) {
    console.error('[-] MySQL 연결 실패:', err.message);
    process.exit(1);
  }
  console.log('[+] MySQL 연결 성공!');

  try {
    for (const table of TARGET_TABLES) {
      console.log(`\n--------------------------------------------------`);
      console.log(`[분석] 테이블: ${table}`);
      console.log(`--------------------------------------------------`);

      const [exists] = await query(`SHOW TABLES LIKE ?`, [table]);
      if (!exists) {
        console.log(`[-] 테이블이 존재하지 않습니다.`);
        continue;
      }

      const cols = await query(`DESCRIBE ??`, [table]);
      console.log(`[컬럼 목록]`);
      cols.forEach(col => {
        console.log(`  - ${col.Field.padEnd(20)} | ${col.Type.padEnd(15)}`);
      });

      const [countRes] = await query(`SELECT COUNT(*) as cnt FROM ??`, [table]);
      console.log(`\n[전체 행(Row) 수] ${countRes.cnt}개`);

      if (countRes.cnt > 0) {
        const samples = await query(`SELECT * FROM ?? LIMIT 5`, [table]);
        samples.forEach((row, idx) => {
          console.log(`  (${idx + 1}) ${JSON.stringify(row, null, 2)}`);
        });
      }
    }
  } catch (ex) {
    console.error('[-] 오류 발생:', ex.message);
  } finally {
    connection.end();
  }
});

function query(sql, params) {
  return new Promise((resolve, reject) => {
    connection.query(sql, params, (err, results) => {
      if (err) reject(err);
      else resolve(results);
    });
  });
}
