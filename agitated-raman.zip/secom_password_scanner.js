/**
 * Secom Manager Database Password Scanner v1.0
 * --------------------------------------------------
 * 이 도구는 세콤 매니저 설치 폴더 내의 실행 파일(.exe) 및 라이브러리(.dll) 내부를
 * 정밀 스캔하여 SQLite DB 접속에 사용되는 비밀번호 후보군 및 연결 설정을 추출합니다.
 * 
 * [실행 방법]
 * 1. 이 파일(secom_password_scanner.js)을 세콤 서버 PC로 복사합니다.
 * 2. 서버 PC의 명령 프롬프트(cmd)에서 다음 명령을 실행합니다:
 *    node secom_password_scanner.js
 * 3. 출력되는 암호 후보군 결과 전체를 복사하여 Antigravity에 전달해주세요.
 */

const fs = require('fs');
const path = require('path');

console.log('==================================================');
console.log(' 세콤 매니저 SQLite 비밀번호 스캔 도구 v1.0');
console.log('==================================================');
console.log('실행 시간:', new Date().toLocaleString());
console.log('OS:', process.platform, process.arch);
console.log('Node.js 버전:', process.version);
console.log('--------------------------------------------------');

// 세콤 매니저 기본 설치 경로 목록
const searchDirs = [
  'C:\\(주)에스원\\세콤매니저(근태·식당) v9.0.1',
  'C:\\(주)에스원\\세콤매니저(근태·식당) v9.0',
  'C:\\(주)에스원\\세콤매니저'
];

let targetDir = null;
for (const dir of searchDirs) {
  if (fs.existsSync(dir)) {
    targetDir = dir;
    break;
  }
}

if (!targetDir) {
  console.error('[오류] 세콤 매니저 설치 경로를 찾을 수 없습니다.');
  console.log('스캔을 진행하려면 스크립트 상단의 searchDirs 배열에 실제 설치 경로를 추가해주세요.');
  process.exit(1);
}

console.log(`[+] 세콤 매니저 설치 경로 확인됨: ${targetDir}`);
console.log('[+] 파일 검색 및 문자열 정밀 스캔을 시작합니다. 잠시만 기다려주세요...\n');

// 1. 디렉토리 내 모든 .exe 및 .dll 파일 수집
function getBinaryFiles(dir) {
  let results = [];
  try {
    const list = fs.readdirSync(dir);
    for (const file of list) {
      const fullPath = path.join(dir, file);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        results = results.concat(getBinaryFiles(fullPath));
      } else {
        const ext = path.extname(file).toLowerCase();
        if (ext === '.exe' || ext === '.dll') {
          results.push({ path: fullPath, name: file, size: stat.size });
        }
      }
    }
  } catch (err) {
    // Ignore error
  }
  return results;
}

const binaries = getBinaryFiles(targetDir);
console.log(`[+] 스캔 대상 파일 개수: ${binaries.length}개`);

// 2. 바이너리 버퍼에서 문자열 추출 (ASCII 및 UTF-16LE)
function extractStrings(buffer) {
  const candidates = [];
  
  // ASCII (영문, 숫자, 특수기호, 길이 6~40)
  let currentAscii = '';
  for (let i = 0; i < buffer.length; i++) {
    const b = buffer[i];
    if (b >= 32 && b <= 126) {
      currentAscii += String.fromCharCode(b);
    } else {
      if (currentAscii.length >= 6 && currentAscii.length <= 40) {
        candidates.push({ val: currentAscii, type: 'ASCII' });
      }
      currentAscii = '';
    }
  }

  // UTF-16LE (C# 닷넷 문자열 리터럴 포맷, 길이 6~40)
  let currentUtf16 = '';
  for (let i = 0; i < buffer.length - 1; i += 2) {
    const b1 = buffer[i];
    const b2 = buffer[i + 1];
    if (b2 === 0 && b1 >= 32 && b1 <= 126) {
      currentUtf16 += String.fromCharCode(b1);
    } else {
      if (currentUtf16.length >= 6 && currentUtf16.length <= 40) {
        candidates.push({ val: currentUtf16, type: 'UTF-16' });
      }
      currentUtf16 = '';
      // 홀수 바이트 정렬 차이 보정
      if (i > 0 && buffer[i] === 0 && buffer[i - 1] >= 32 && buffer[i - 1] <= 126) {
        i--;
      }
    }
  }

  return candidates;
}

// 3. 비밀번호 의심 키워드 필터 및 점수 부여
function inspectStrings(strings) {
  const filtered = [];
  const seen = new Set();

  for (const item of strings) {
    const str = item.val.trim();
    if (seen.has(str)) continue;
    seen.add(str);

    // 공통 C# 네임스페이스, 프레임워크 라이브러리 및 XML 요소 등은 제외
    if (/^Microsoft|^System|^Windows|^Newtonsoft|^SQLite|^EntityFramework|^Google|^\<|\/|xmlns|version=|culture=/i.test(str)) {
      continue;
    }

    // 소스코드 지시어나 흔한 영어 단어/구조 제외
    if (/^get_|^set_|^add_|^remove_|^op_|^ctor|EventArgs|Callback|ToString|Dispose|NullReference|Exception|Invoke|Property/i.test(str)) {
      continue;
    }

    let score = 0;
    
    // 알파벳과 숫자가 혼용된 형태는 패스워드일 확률이 높음
    if (/[a-zA-Z]/.test(str) && /[0-9]/.test(str)) {
      score += 10;
    }
    // 특수기호가 섞여있으면 점수 추가
    if (/[!@#$%^&*()_+\-=\[\]{};':",./<>?]/.test(str)) {
      score += 5;
    }
    // "Password", "PWD", "Key", "Security" 등이 포함되거나 근처 문자열인 경우 보정
    if (/pass|pwd|crypt|key|secure|conn|admin/i.test(str)) {
      score += 15;
    }
    // 일반적인 세콤 DSN 설정이나 관련 약어
    if (/s1|secom|hecto|sese/i.test(str)) {
      score += 8;
    }

    // 숫자로만 구성되어 있거나 특정 길이를 만족할 때
    if (/^\d{8,15}$/.test(str)) {
      score += 8; // 예: "1618801296" 같은 숫자 패스워드
    }

    if (score > 0) {
      filtered.push({ val: str, type: item.type, score });
    }
  }

  // 높은 점수 순으로 정렬
  return filtered.sort((a, b) => b.score - a.score);
}

// 4. 메인 실행 루프
const findings = {};

for (const bin of binaries) {
  // 특정 핵심 파일들에 우선순위 부여
  const isTargetFile = ['WorkManager.exe', 'HRServiceUI.exe', 'FaceAgent.exe'].includes(bin.name) || bin.name.includes('HRService');
  
  if (bin.size > 20 * 1024 * 1024) {
    // 20MB 이상은 너무 큰 어셈블리이므로 건너뛰거나 특정 타겟 파일일 경우에만 로드
    if (!isTargetFile) continue;
  }

  try {
    const buffer = fs.readFileSync(bin.path);
    const rawStrings = extractStrings(buffer);
    const analyzed = inspectStrings(rawStrings);
    
    if (analyzed.length > 0) {
      findings[bin.name] = analyzed.slice(0, 30); // 파일별 상위 30개만 수집
    }
  } catch (err) {
    console.error(`[-] 파일 읽기 실패 (${bin.name}): ${err.message}`);
  }
}

// 5. 결과 출력
console.log('==================================================');
console.log('★ 비밀번호 후보 및 주요 연결 문자열 스캔 결과 ★');
console.log('==================================================');

let foundAny = false;
for (const [filename, candidates] of Object.entries(findings)) {
  console.log(`\n▶ 파일: ${filename}`);
  console.log('--------------------------------------------------');
  
  const highScores = candidates.filter(c => c.score >= 10);
  if (highScores.length === 0) {
    console.log('  (의심스러운 비밀번호가 감지되지 않았습니다.)');
    continue;
  }
  
  foundAny = true;
  highScores.slice(0, 15).forEach((cand, idx) => {
    console.log(`  [후보 ${idx + 1}] "${cand.val}"  (유형: ${cand.type}, 지수: ${cand.score})`);
  });
}

if (!foundAny) {
  console.log('\n[!] 의심스러운 어셈블리 비밀번호 후보를 검출하지 못했습니다.');
}

console.log('\n==================================================');
console.log('스캔 완료. 출력 내용을 복사하여 Antigravity에 전달해주세요.');
console.log('==================================================');
