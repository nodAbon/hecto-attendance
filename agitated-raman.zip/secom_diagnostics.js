/**
 * Secom Manager Server PC Diagnostics Script
 * --------------------------------------------------
 * 이 스크립트는 세콤 매니저가 설치된 서버 PC에서 실행하여 
 * 데이터베이스 연결 정보, 레지스트리 설정(ODBC DSN) 및 관련 설정 파일을 분석합니다.
 * 
 * 실행 방법:
 * 1. 이 파일(secom_diagnostics.js)을 서버 PC로 복사합니다.
 * 2. 서버 PC의 명령 프롬프트(cmd)에서 다음 명령을 실행합니다:
 *    node secom_diagnostics.js
 * 3. 출력된 결과를 복사하여 여기에 전달해주세요.
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('==================================================');
console.log(' 세콤 매니저 데이터베이스 서버 PC 진단 도구 v1.1');
console.log('==================================================');
console.log('실행 시간:', new Date().toLocaleString());
console.log('OS:', process.platform, process.arch);
console.log('Node.js 버전:', process.version);
console.log('--------------------------------------------------');

// 1. 기본 경로 및 설치 상태 확인
const defaultPaths = [
  'C:\\(주)에스원\\세콤매니저(근태·식당) v9.0.1',
  'C:\\(주)에스원\\세콤매니저(근태·식당) v9.0',
  'C:\\(주)에스원\\세콤매니저(근태·식당) v9',
  'C:\\(주)에스원\\세콤매니저',
  'C:\\Program Files\\세콤매니저',
  'C:\\Program Files (x86)\\세콤매니저',
  'C:\\S1\\세콤매니저'
];

console.log('\n[1] 설치 폴더 스캔:');
for (let i = 0; i < defaultPaths.length; i++) {
  const dir = defaultPaths[i];
  if (fs.existsSync(dir)) {
    console.log(`  [O] 발견됨: ${dir}`);
    try {
      const files = fs.readdirSync(dir);
      console.log(`      - 파일 개수: ${files.length}개`);
      
      // 설정 파일 검색 (.ini, .config, .xml, .cfg 등)
      for (let j = 0; j < files.length; j++) {
        const file = files[j];
        const ext = path.extname(file).toLowerCase();
        if (ext === '.ini' || ext === '.cfg' || ext === '.xml' || ext === '.config' || ext === '.txt' || ext === '.json') {
          const cfgPath = path.join(dir, file);
          const size = fs.statSync(cfgPath).size;
          if (size < 50000) { // 50KB 이하 파일만 분석
            console.log(`      >>> [파일 분석] ${file} (${size} bytes)`);
            const content = fs.readFileSync(cfgPath, 'utf8');
            const lines = content.split('\n');
            let foundKeywords = false;
            for (let k = 0; k < lines.length; k++) {
              const line = lines[k];
              if (/db|database|sqlite|sqlcipher|pass|pw|key|port|connect|dsn|whois|jobcan/i.test(line)) {
                if (!foundKeywords) {
                  console.log('        * 발견된 DB/비밀번호 관련 설정 라인:');
                  foundKeywords = true;
                }
                console.log(`          ${line.trim()}`);
              }
            }
          }
        }
      }
      
      // Database 폴더 확인
      const dbSubdir = path.join(dir, 'Database');
      if (fs.existsSync(dbSubdir)) {
        console.log(`      [O] Database 폴더 존재: ${dbSubdir}`);
        console.log(`          - DB 폴더 파일 목록:`, fs.readdirSync(dbSubdir));
        
        const mainDbPath = path.join(dbSubdir, 'MainDB');
        if (fs.existsSync(mainDbPath)) {
          console.log(`          [O] MainDB 폴더 존재: ${mainDbPath}`);
          console.log(`              - 파일 목록:`, fs.readdirSync(mainDbPath));
        }
      }
    } catch (err) {
      console.log(`      - 폴더 읽기 실패: ${err.message}`);
    }
  } else {
    console.log(`  [X] 없음: ${dir}`);
  }
}

// 2. Windows 레지스트리에서 ODBC DSN 설정 조회
console.log('\n[2] Windows ODBC DSN 레지스트리 정보 검색:');
const regQueries = [
  { name: 'System DSN (32-bit)', cmd: 'reg query "HKLM\\SOFTWARE\\Wow6432Node\\ODBC\\ODBC.INI" /s' },
  { name: 'System DSN (64-bit)', cmd: 'reg query "HKLM\\SOFTWARE\\ODBC\\ODBC.INI" /s' },
  { name: 'User DSN', cmd: 'reg query "HKCU\\SOFTWARE\\ODBC\\ODBC.INI" /s' }
];

for (let i = 0; i < regQueries.length; i++) {
  const q = regQueries[i];
  try {
    console.log(`  - ${q.name} 조회 시도...`);
    const output = execSync(q.cmd, { encoding: 'utf8', stdio: ['pipe', 'pipe', 'ignore'] });
    console.log(`    >>> ${q.name} 설정 값 발견:`);
    
    const lines = output.split('\n');
    let currentKey = '';
    for (let j = 0; j < lines.length; j++) {
      const line = lines[j];
      const trimmed = line.trim();
      if (trimmed.startsWith('HKEY_')) {
        currentKey = trimmed.substring(trimmed.lastIndexOf('\\') + 1);
        console.log(`      [DSN: ${currentKey}]`);
      } else if (trimmed && currentKey) {
        console.log(`        ${trimmed}`);
      }
    }
  } catch (err) {
    console.log(`    (Dsn이 비어있거나 검색 명령어를 실행할 수 없음)`);
  }
}

// 3. SQLite3 ODBC Driver 설치 여부 확인
console.log('\n[3] 설치된 ODBC 드라이버 목록 확인:');
const driverQueries = [
  'reg query "HKLM\\SOFTWARE\\ODBC\\ODBCINST.INI\\ODBC Drivers"',
  'reg query "HKLM\\SOFTWARE\\Wow6432Node\\ODBC\\ODBCINST.INI\\ODBC Drivers"'
];

for (let i = 0; i < driverQueries.length; i++) {
  const cmd = driverQueries[i];
  try {
    const output = execSync(cmd, { encoding: 'utf8', stdio: ['pipe', 'pipe', 'ignore'] });
    const lines = output.split('\n');
    for (let j = 0; j < lines.length; j++) {
      const line = lines[j];
      if (line.trim() && !line.includes('HKEY_')) {
        if (/sqlite|sqlserver|secom/i.test(line)) {
          console.log(`  [Driver] ${line.trim()}`);
        }
      }
    }
  } catch (e) {
    // ignore
  }
}

// 4. 실행 중인 세콤 프로세스 확인
console.log('\n[4] 실행 중인 세콤 프로세스 검색:');
try {
  const tasklist = execSync('tasklist', { encoding: 'utf8' });
  const lines = tasklist.split('\n');
  let foundTasks = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (/workmanager|secom|s1|esp|commute/i.test(line)) {
      if (!foundTasks) {
        console.log('  실행 중인 관련 프로세스:');
        foundTasks = true;
      }
      console.log(`    ${line.trim()}`);
    }
  }
  if (!foundTasks) {
    console.log('  실행 중인 세콤 관련 프로세스가 없습니다.');
  }
} catch (err) {
  console.log('  프로세스 목록을 불러오지 못했습니다:', err.message);
}

console.log('\n==================================================');
console.log('진단 완료. 위 내용을 복사하여 Antigravity에 전달해주세요.');
console.log('==================================================');
