import { NextResponse } from 'next/server';
import { fetchAttendanceLogs, getSettings } from '@/lib/secomDb';

export async function GET() {
  try {
    const settings = getSettings();
    const { logs, isDemo, error } = await fetchAttendanceLogs();

    // 1. Process stats based on logs
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0]; // "YYYY-MM-DD"
    
    // Get all logs of today (local time)
    // Logs are in "YYYY-MM-DD HH:MM:SS" format
    const todayLogs = logs.filter(log => log.logTime.startsWith(todayStr));
    
    // Group logs by employee for today
    const empTodayMap = new Map();
    todayLogs.forEach(log => {
      if (!empTodayMap.has(log.empNo)) {
        empTodayMap.set(log.empNo, []);
      }
      empTodayMap.get(log.empNo).push(log);
    });

    // Unique employees list across logs to identify all known employees
    const allEmployeesMap = new Map();
    logs.forEach(log => {
      allEmployeesMap.set(log.empNo, {
        empNo: log.empNo,
        name: log.name,
        dept: log.dept,
        cardNo: log.cardNo
      });
    });
    
    const totalEmployeesCount = allEmployeesMap.size || 10;
    const presentEmpNos = new Set(empTodayMap.keys());
    const presentCount = presentEmpNos.size;
    const absentCount = Math.max(0, totalEmployeesCount - presentCount);

    let lateCount = 0;
    let workingNowCount = 0;
    const employeeStatuses = [];

    // Calculate details for each employee today
    allEmployeesMap.forEach((emp, empNo) => {
      const empLogs = empTodayMap.get(empNo) || [];
      
      if (empLogs.length > 0) {
        // Sort logs for this employee today by time ascending
        const sortedLogs = [...empLogs].sort((a, b) => a.logTime.localeCompare(b.logTime));
        const firstLog = sortedLogs[0];
        const lastLog = sortedLogs[sortedLogs.length - 1];

        // Is late? (If first check-in is after 09:00:00)
        // Time format: "YYYY-MM-DD HH:MM:SS"
        const checkInTimeOnly = firstLog.logTime.split(' ')[1]; // "HH:MM:SS"
        const isLate = checkInTimeOnly > '09:00:00';
        if (isLate) lateCount++;

        // Is currently working? (If last event is not "퇴근")
        const isCheckedOut = lastLog.eventType === '퇴근';
        const status = isCheckedOut ? '퇴근' : '근무중';
        if (status === '근무중') workingNowCount++;

        employeeStatuses.push({
          ...emp,
          status,
          checkIn: firstLog.logTime.split(' ')[1].substring(0, 5), // "HH:MM"
          checkOut: isCheckedOut ? lastLog.logTime.split(' ')[1].substring(0, 5) : '-',
          isLate,
          lastGate: lastLog.gateName
        });
      } else {
        employeeStatuses.push({
          ...emp,
          status: '미출근',
          checkIn: '-',
          checkOut: '-',
          isLate: false,
          lastGate: '-'
        });
      }
    });

    // 2. Generate Weekly Trend Data (Last 7 Days)
    const weeklyTrend = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(now.getDate() - i);
      const dStr = d.toISOString().split('T')[0];
      const dayName = d.toLocaleDateString('ko-KR', { weekday: 'short' }); // "월", "화" 등
      
      // Count unique employees who checked in on day dStr
      const dayEmpNos = new Set(
        logs
          .filter(log => log.logTime.startsWith(dStr))
          .map(log => log.empNo)
      );

      // Skip weekends for trend if they have no entries
      if ((d.getDay() === 0 || d.getDay() === 6) && dayEmpNos.size === 0) continue;

      weeklyTrend.push({
        date: dStr.substring(5, 10).replace('-', '/'), // "05/22"
        dayName,
        count: dayEmpNos.size,
        rate: Math.round((dayEmpNos.size / totalEmployeesCount) * 100) || 0
      });
    }

    // 3. Department Wise distribution
    const deptDistribution = {};
    employeeStatuses.forEach(emp => {
      if (!deptDistribution[emp.dept]) {
        deptDistribution[emp.dept] = { total: 0, present: 0, late: 0 };
      }
      deptDistribution[emp.dept].total++;
      if (emp.status !== '미출근') {
        deptDistribution[emp.dept].present++;
        if (emp.isLate) deptDistribution[emp.dept].late++;
      }
    });

    const formattedDeptData = Object.keys(deptDistribution).map(dept => ({
      name: dept,
      total: deptDistribution[dept].total,
      present: deptDistribution[dept].present,
      late: deptDistribution[dept].late
    }));

    // Return payload
    return NextResponse.json({
      success: true,
      isDemo,
      error: error || null,
      mode: settings.appMode,
      dbPath: settings.secomDbPath,
      stats: {
        totalEmployees: totalEmployeesCount,
        present: presentCount,
        absent: absentCount,
        late: lateCount,
        workingNow: workingNowCount,
        attendanceRate: totalEmployeesCount > 0 ? Math.round((presentCount / totalEmployeesCount) * 100) : 0
      },
      weeklyTrend,
      deptData: formattedDeptData,
      employeeStatuses: employeeStatuses.sort((a, b) => {
        // Sort working now first, then present, then absent
        const statusPriority = { '근무중': 1, '퇴근': 2, '미출근': 3 };
        return statusPriority[a.status] - statusPriority[b.status] || a.name.localeCompare(b.name);
      }),
      // Show latest 15 logs for live feed
      recentLogs: logs.slice(0, 15).map(log => ({
        ...log,
        timeOnly: log.logTime.split(' ')[1].substring(0, 5), // "HH:MM"
        dateOnly: log.logTime.split(' ')[0].substring(5, 10).replace('-', '/') // "05/22"
      }))
    });

  } catch (err) {
    console.error('API attendance error:', err);
    return NextResponse.json({
      success: false,
      error: err.message
    }, { status: 500 });
  }
}
