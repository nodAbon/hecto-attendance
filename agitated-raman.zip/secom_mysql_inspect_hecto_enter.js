const mysql = require('mysql2/promise');

const MYSQL_CONFIG = {
  host: 'Prd-Hecto-WHR-Ext-NLB-8e82b66ed560637d.elb.ap-northeast-2.amazonaws.com',
  user: 'whradmin',
  password: '1q2w3e4r!@#$',
  database: 'whr',
  port: 3306,
  connectTimeout: 5000
};

async function inspectHectoEnter() {
  console.log('==================================================');
  console.log(' Hecto Enter 테이블 분석');
  console.log('==================================================');

  try {
    const connection = await mysql.createConnection(MYSQL_CONFIG);
    console.log('[+] MySQL 연결 성공!');

    const targetTables = ['hecto_enter', 'hecto_enter_temp', 'am_access_log'];

    for (const table of targetTables) {
      console.log(`\n--------------------------------------------------`);
      console.log(`[분석] 테이블: ${table}`);
      console.log(`--------------------------------------------------`);

      try {
        // 1. 컬럼 목록 조회 (DESCRIBE)
        const [cols] = await connection.query(`DESCRIBE ${table}`);
        console.log('  - 컬럼 목록:');
        console.table(cols.map(c => ({ Field: c.Field, Type: c.Type })));

        // 2. 전체 행 수
        const [countRes] = await connection.query(`SELECT COUNT(*) as cnt FROM ${table}`);
        const totalRows = countRes[0].cnt;
        console.log(`  - 전체 행 수: ${totalRows}개`);

        if (totalRows > 0) {
          // 3. 정렬 컬럼 확인
          const hasDate = cols.some(c => c.Field.toLowerCase().includes('date') || c.Field.toLowerCase().includes('time') || c.Field.toLowerCase().includes('atime'));
          let querySql = `SELECT * FROM ${table}`;
          if (hasDate) {
            // E_DATE, E_TIME 또는 다른 날짜 컬럼으로 정렬 시도
            const orderCol = cols.some(c => c.Field === 'E_DATE') ? 'E_DATE DESC, E_TIME DESC' : 
                             cols.some(c => c.Field === 'log_date') ? 'log_date DESC, log_time DESC' :
                             cols.some(c => c.Field.toLowerCase().includes('date')) ? cols.find(c => c.Field.toLowerCase().includes('date')).Field + ' DESC' :
                             cols[0].Field + ' DESC';
            querySql += ` ORDER BY ${orderCol}`;
            console.log(`  - 정렬 기준: ${orderCol}`);
          }
          querySql += ` LIMIT 5`;

          const [samples] = await connection.query(querySql);
          console.log('  - 최신 데이터 5건:');
          console.log(JSON.stringify(samples, null, 2));
        } else {
          console.log('  - 데이터가 비어 있습니다.');
        }
      } catch (e) {
        console.error(`  [-] ${table} 분석 실패:`, e.message);
      }
    }

    // 3. G_ID 값을 가지고 있는 고유한 값 목록과 테이블 매핑 분석
    console.log('\n--------------------------------------------------');
    console.log('[게이트 코드 매핑 분석]');
    console.log('--------------------------------------------------');

    try {
      console.log('\n* tenter 테이블의 고유 G_ID 목록:');
      const [tenterGids] = await connection.query(`
        SELECT G_ID, COUNT(*) as cnt, MIN(E_DATE) as min_date, MAX(E_DATE) as max_date 
        FROM tenter 
        GROUP BY G_ID
      `);
      console.table(tenterGids);
    } catch (e) {
      console.log('tenter G_ID 집계 실패:', e.message);
    }

    try {
      console.log('\n* hecto_enter 테이블의 고유 G_ID 목록:');
      const [hectoGids] = await connection.query(`
        SELECT G_ID, COUNT(*) as cnt 
        FROM hecto_enter 
        GROUP BY G_ID
      `);
      console.table(hectoGids);
    } catch (e) {
      console.log('hecto_enter G_ID 집계 실패:', e.message);
    }

    await connection.end();
  } catch (err) {
    console.error('[-] 오류:', err.message);
  }
}

inspectHectoEnter();
