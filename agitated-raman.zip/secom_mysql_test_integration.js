/**
 * Secom MySQL Integrated Query & Classification Test Script v1.0
 * --------------------------------------------------
 * 이 도구는 실제 대시보드 백엔드(secomDb.js)에서 사용하는 동일한 SQL 조인 쿼리와
 * 동적 출퇴근(In/Out) 판정 알고리즘이 서버 PC에서 올바르게 동작하는지 독립적으로 검증합니다.
 * 
 * [실행 방법]
 * 1. 이 파일(secom_mysql_test_integration.js)을 세콤 서버 PC로 복사합니다.
 * 2. 서버 PC의 명령 프롬프트(cmd)에서 다음 명령을 실행합니다:
 *    node secom_mysql_test_integration.js
 * 3. 출력 결과를 복사하여 전달해주세요.
 */

const mysql = require('mysql2/promise');

const MYSQL_CONFIG = {
  host: 'Prd-Hecto-WHR-Ext-NLB-8e82b66ed560637d.elb.ap-northeast-2.amazonaws.com',
  user: 'whradmin',
  password: '1q2w3e4r!@#$',
  database: 'whr',
  port: 3306,
  connectTimeout: 5000
};

function formatRawTime(rawTime) {
  if (!rawTime || rawTime.length < 14) {
    return new Date().toISOString().replace('T', ' ').substring(0, 19);
  }
  const year = rawTime.substring(0, 4);
  const month = rawTime.substring(4, 6);
  const day = rawTime.substring(6, 8);
  const hour = rawTime.substring(8, 10);
  const min = rawTime.substring(10, 12);
  const sec = rawTime.substring(12, 14);
  return `${year}-${month}-${day} ${hour}:${min}:${sec}`;
}

function processMySQLRows(rows) {
  // Format raw fields to frontend format
  const logsWithTime = rows.map(r => ({
    empNo: r.empNo || 'Unknown',
    name: r.name || '방문객',
    dept: r.dept || '부서없음',
    cardNo: r.cardNo || 'Unknown',
    logTime: formatRawTime(r.rawTime),
    gateName: r.gateCode === 1000 ? '정문 게이트' : `게이트 (${r.gateCode})`,
    eventType: '출입'
  }));

  // Group logs by empNo and Date (YYYY-MM-DD)
  const groups = {};
  logsWithTime.forEach(log => {
    const dateStr = log.logTime.split(' ')[0];
    const key = `${log.empNo}_${dateStr}`;
    if (!groups[key]) {
      groups[key] = [];
    }
    groups[key].push(log);
  });

  // Calculate Clock In / Clock Out per day per employee
  Object.keys(groups).forEach(key => {
    const groupLogs = groups[key];
    groupLogs.sort((a, b) => a.logTime.localeCompare(b.logTime));

    if (groupLogs.length === 1) {
      const hour = parseInt(groupLogs[0].logTime.split(' ')[1].split(':')[0], 10);
      groupLogs[0].eventType = hour < 13 ? '출근' : '퇴근';
    } else {
      groupLogs[0].eventType = '출근';
      groupLogs[groupLogs.length - 1].eventType = '퇴근';
      for (let i = 1; i < groupLogs.length - 1; i++) {
        groupLogs[i].eventType = '출입';
      }
    }
  });

  // Sort logs by time descending (newest first)
  return logsWithTime.sort((a, b) => b.logTime.localeCompare(a.logTime));
}

async function runTest() {
  console.log('==================================================');
  console.log(' 세콤 MySQL 통합 쿼리 및 출퇴근 판정 검증 v1.0');
  console.log('==================================================');
  console.log('[1] MySQL DB 연결 시도...');

  try {
    const connection = await mysql.createConnection(MYSQL_CONFIG);
    console.log('[+] 연결 성공!');

    console.log('\n[2] 세콤 로그 + 사원 마스터 + 부서 정보 조인 쿼리 실행 중...');
    
    // t_secom_alarm 테이블을 hr_employee, hr_department 와 조인하여 가져옴
    const [rows] = await connection.execute(`
      SELECT 
        COALESCE(NULLIF(a.Sabun, ''), e.I_EMPLOY_NO, 'Unknown') AS empNo,
        COALESCE(NULLIF(a.Name, ''), e.N_EMPLOY_NAME, '방문객') AS name,
        COALESCE(d.N_DEPT, '부서없음') AS dept,
        a.CardNo AS cardNo,
        a.ATime AS rawTime,
        a.EqCode AS gateCode,
        a.State AS state
      FROM t_secom_alarm a
      LEFT JOIN hr_employee e ON 
        (a.Sabun IS NOT NULL AND a.Sabun <> '' AND e.I_EMPLOY_NO = RIGHT(a.Sabun, 8))
        OR
        ((a.Sabun IS NULL OR a.Sabun = '') AND e.N_EMPLOY_NAME = a.Name)
      LEFT JOIN hr_department d ON d.I_DEPT = e.I_DEPT
      ORDER BY a.ATime DESC
      LIMIT 1000
    `);

    await connection.end();

    console.log(`[+] 쿼리 완료! 로드된 로우 수: ${rows.length}개`);

    if (rows.length === 0) {
      console.log('[-] 데이터가 존재하지 않습니다.');
      return;
    }

    console.log('\n[3] JavaScript 단 출퇴근 판정 알고리즘 적용 중...');
    const processedLogs = processMySQLRows(rows);
    console.log('[+] 판정 완료!');

    console.log('\n[4] 최근 판정 완료된 로그 10건 샘플 출력:');
    processedLogs.slice(0, 10).forEach((log, idx) => {
      console.log(`  (${idx + 1}) [${log.logTime}] 사번: ${log.empNo} | 이름: ${log.name} | 부서: ${log.dept} | 구분: ${log.eventType} | 게이트: ${log.gateName}`);
    });

    console.log('\n[5] 출근/퇴근/출입 판정 통계:');
    const stats = { 출근: 0, 퇴근: 0, 출입: 0 };
    processedLogs.forEach(log => {
      stats[log.eventType] = (stats[log.eventType] || 0) + 1;
    });
    console.log(`  - 출근 로그: ${stats.출근}건`);
    console.log(`  - 퇴근 로그: ${stats.퇴근}건`);
    console.log(`  - 일반 출입: ${stats.출입}건`);

    console.log('\n[결론] 이 쿼리와 알고리즘은 정상 작동합니다! 대시보드 화면에 바로 적용 가능합니다.');

  } catch (err) {
    console.error('\n[-] 검증 실패:', err.message);
  }
}

runTest();
