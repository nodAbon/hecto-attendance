/**
 * Secom MySQL Join & Gate Mapping Diagnosis Script v1.1
 */

const mysql = require('mysql2/promise');

const MYSQL_CONFIG = {
  host: 'Prd-Hecto-WHR-Ext-NLB-8e82b66ed560637d.elb.ap-northeast-2.amazonaws.com',
  user: 'whradmin',
  password: '1q2w3e4r!@#$',
  database: 'whr',
  port: 3306,
  connectTimeout: 5000
};

async function runDiagnosis() {
  console.log('==================================================');
  console.log(' 세콤 MySQL 조인 매핑 및 게이트 명칭 분석 v1.1');
  console.log('==================================================');

  try {
    const connection = await mysql.createConnection(MYSQL_CONFIG);
    console.log('[+] MySQL 연결 성공!');

    // 1. tenter 테이블 확인
    console.log('\n[1] tenter 테이블 확인:');
    try {
      const [tenterRows] = await connection.execute('SELECT * FROM tenter LIMIT 10');
      console.log(JSON.stringify(tenterRows, null, 2));
    } catch (e) {
      console.log('[-] tenter 테이블 조회 실패:', e.message);
    }

    // 2. manual_tenter 테이블 확인
    console.log('\n[2] manual_tenter 테이블 확인:');
    try {
      const [manualRows] = await connection.execute('SELECT * FROM manual_tenter LIMIT 10');
      console.log(JSON.stringify(manualRows, null, 2));
    } catch (e) {
      console.log('[-] manual_tenter 테이블 조회 실패:', e.message);
    }

    // 3. t_secom_alarm 의 EqCode와 Master 고유값 확인
    console.log('\n[3] t_secom_alarm 테이블의 고유한 EqCode와 Master 목록 조회:');
    const [eqCodes] = await connection.execute(`
      SELECT EqCode, Master, COUNT(*) as cnt 
      FROM t_secom_alarm 
      GROUP BY EqCode, Master
    `);
    console.log(JSON.stringify(eqCodes, null, 2));

    // 4. 새로운 정밀 JOIN 쿼리 테스트 (이준환 대상)
    console.log('\n[4] 정밀 JOIN 쿼리 테스트 (이준환 대상):');
    const [testRows] = await connection.execute(`
      SELECT 
        a.ATime AS rawTime,
        a.Sabun AS sabun,
        a.Name AS name,
        e.I_COMPANY AS company,
        e.N_EMPLOY_NAME AS empName,
        d.N_DEPT AS dept,
        a.EqCode AS gateCode,
        a.State AS state
      FROM t_secom_alarm a
      LEFT JOIN hr_employee e ON 
        e.I_COMPANY = LEFT(a.Sabun, 4) AND e.I_EMPLOY_NO = RIGHT(a.Sabun, 8)
      LEFT JOIN hr_department d ON 
        d.I_COMPANY = e.I_COMPANY AND d.I_DEPT = e.I_DEPT
      WHERE a.Name = '이준환'
      ORDER BY a.ATime DESC
      LIMIT 5
    `);
    console.log(JSON.stringify(testRows, null, 2));

    await connection.end();
  } catch (err) {
    console.error('[-] 분석 실패:', err.message);
  }
}

runDiagnosis();
