const fs = require('fs');
const readline = require('readline');
const path = require('path');

const transcriptPath = 'C:\\Users\\Owner\\.gemini\\antigravity\\brain\\b55facfe-7a42-4fcc-947a-e92ad14471e0\\.system_generated\\logs\\transcript.jsonl';

async function search() {
  const fileStream = fs.createReadStream(transcriptPath);
  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity
  });

  let lineNum = 0;
  for await (const line of rl) {
    lineNum++;
    try {
      const obj = JSON.parse(line);
      const contentStr = obj.content || JSON.stringify(obj.tool_calls) || '';
      if (contentStr.includes('t_secom_alarm') && (contentStr.includes('ATime') || contentStr.includes('EqCode'))) {
        console.log(`=== Line ${lineNum} ===`);
        console.log(contentStr.substring(0, 1500));
      }
    } catch (e) {}
  }
}

search();
