/**
 * Secom MySQL Table Schema & Data Inspector v1.0
 * --------------------------------------------------
 * 이 도구는 Hecto_Live MySQL DB에 접속하여 세콤 관련 주요 테이블의 스키마와
 * 실제 저장된 데이터의 샘플을 조회하여 어떻게 근태 기록을 파싱할 수 있는지 분석합니다.
 * 
 * [실행 방법]
 * 1. 이 파일(secom_mysql_inspect.js)을 세콤 서버 PC로 복사합니다.
 * 2. 서버 PC의 명령 프롬프트(cmd)에서 다음 명령을 실행합니다:
 *    node secom_mysql_inspect.js
 * 3. 출력 결과를 복사하여 전달해주세요.
 */

const mysql = require('mysql2');

const config = {
  host: 'Prd-Hecto-WHR-Ext-NLB-8e82b66ed560637d.elb.ap-northeast-2.amazonaws.com',
  user: 'whradmin',
  password: '1q2w3e4r!@#$',
  database: 'whr',
  port: 3306,
  connectTimeout: 5000
};

console.log('==================================================');
console.log(' 세콤 MySQL 테이블 구조 및 데이터 분석 도구 v1.0');
console.log('==================================================');

const connection = mysql.createConnection(config);

const TARGET_TABLES = [
  't_secom_alarm',
  't_secom_person_p',
  'employee',
  'hr_employee',
  'caps1200'
];

connection.connect(async (err) => {
  if (err) {
    console.error('[-] MySQL 연결 실패:', err.message);
    process.exit(1);
  }
  console.log('[+] MySQL 연결 성공!');

  try {
    for (const table of TARGET_TABLES) {
      console.log(`\n--------------------------------------------------`);
      console.log(`[분석] 테이블: ${table}`);
      console.log(`--------------------------------------------------`);

      // 1. 테이블 존재 여부 확인
      const [exists] = await query(`SHOW TABLES LIKE ?`, [table]);
      if (!exists) {
        console.log(`[-] 테이블이 존재하지 않습니다.`);
        continue;
      }

      // 2. 컬럼 구조(Schema) 조회
      const cols = await query(`DESCRIBE ??`, [table]);
      console.log(`[컬럼 목록]`);
      cols.forEach(col => {
        console.log(`  - ${col.Field.padEnd(20)} | ${col.Type.padEnd(15)} | Null: ${col.Null.padEnd(3)} | Key: ${col.Key}`);
      });

      // 3. 전체 데이터 수 조회
      const [countRes] = await query(`SELECT COUNT(*) as cnt FROM ??`, [table]);
      const count = countRes.cnt;
      console.log(`\n[전체 행(Row) 수] ${count}개`);

      if (count > 0) {
        // 4. 최근/샘플 데이터 5건 조회
        // 정렬할 컬럼 찾기 (일시 관련 컬럼이 있는지 확인)
        const dateCol = cols.find(c => 
          c.Field.toLowerCase().includes('date') || 
          c.Field.toLowerCase().includes('time') || 
          c.Field.toLowerCase().includes('dt')
        );

        let selectSql = `SELECT * FROM ??`;
        if (dateCol) {
          selectSql += ` ORDER BY ${dateCol.Field} DESC`;
          console.log(`\n[샘플 데이터 5건] (${dateCol.Field} 기준 정렬)`);
        } else {
          console.log(`\n[샘플 데이터 5건]`);
        }
        selectSql += ` LIMIT 5`;

        const samples = await query(selectSql, [table]);
        samples.forEach((row, idx) => {
          console.log(`  (${idx + 1}) ${JSON.stringify(row, null, 2)}`);
        });
      } else {
        console.log(`\n[안내] 데이터가 비어 있습니다.`);
      }
    }
  } catch (ex) {
    console.error('[-] 오류 발생:', ex.message);
  } finally {
    connection.end();
    console.log('\n==================================================');
    console.log(' 분석이 완료되었습니다.');
    console.log('==================================================');
  }
});

function query(sql, params) {
  return new Promise((resolve, reject) => {
    connection.query(sql, params, (err, results) => {
      if (err) reject(err);
      else resolve(results);
    });
  });
}
