/**
 * Secom MySQL Gate & Reader Analysis Tool
 */

const mysql = require('mysql2/promise');

const MYSQL_CONFIG = {
  host: 'Prd-Hecto-WHR-Ext-NLB-8e82b66ed560637d.elb.ap-northeast-2.amazonaws.com',
  user: 'whradmin',
  password: '1q2w3e4r!@#$',
  database: 'whr',
  port: 3306,
  connectTimeout: 5000
};

async function runAnalysis() {
  console.log('==================================================');
  console.log(' 세콤 MySQL 게이트/리더기 및 최신 로그 분석 도구');
  console.log('==================================================');

  try {
    const connection = await mysql.createConnection(MYSQL_CONFIG);
    console.log('[+] MySQL 연결 성공!');

    // 1. 전체 테이블 목록 조회
    console.log('\n[1] 데이터베이스 내 전체 테이블 목록:');
    const [tables] = await connection.execute('SHOW TABLES');
    const tableNames = tables.map(t => Object.values(t)[0]);
    console.log(tableNames.join(', '));

    // 2. tenter 테이블 최신 데이터 조회 (ORDER BY 적용)
    console.log('\n[2] tenter 테이블 최신 데이터 5건 (정렬 적용):');
    try {
      const [tenterCount] = await connection.execute('SELECT COUNT(*) as cnt FROM tenter');
      console.log(`  - 전체 행 수: ${tenterCount[0].cnt}개`);
      
      const [tenterRecent] = await connection.execute(`
        SELECT * FROM tenter 
        ORDER BY E_DATE DESC, E_TIME DESC 
        LIMIT 5
      `);
      console.log(JSON.stringify(tenterRecent, null, 2));
    } catch (e) {
      console.log('  [-] tenter 조회 실패:', e.message);
    }

    // 3. caps1200 테이블 최신 데이터 및 구조 조회
    console.log('\n[3] caps1200 테이블 최신 데이터 및 구조:');
    try {
      const [capsCount] = await connection.execute('SELECT COUNT(*) as cnt FROM caps1200');
      console.log(`  - 전체 행 수: ${capsCount[0].cnt}개`);
      
      const [capsCols] = await connection.execute('DESCRIBE caps1200');
      console.log('  - 컬럼 목록:');
      console.table(capsCols.map(c => ({ Field: c.Field, Type: c.Type })));

      // caps1200 최신 데이터 조회 (날짜 컬럼 유추 또는 E_DATE)
      const dateCol = capsCols.find(c => ['e_date', 'e_time', 'atime', 'log_time'].includes(c.Field.toLowerCase()))?.Field || capsCols[0].Field;
      console.log(`  - 정렬 컬럼: ${dateCol}`);
      
      const [capsRecent] = await connection.execute(`
        SELECT * FROM caps1200 
        ORDER BY ${dateCol} DESC 
        LIMIT 5
      `);
      console.log(JSON.stringify(capsRecent, null, 2));
    } catch (e) {
      console.log('  [-] caps1200 조회 실패:', e.message);
    }

    // 4. 게이트/리더기 코드(G_ID, EqCode) 매핑 테이블 찾기
    console.log('\n[4] G_ID 또는 게이트 관련 컬럼을 포함하는 테이블 검색:');
    const [mappingCols] = await connection.execute(`
      SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE 
      FROM information_schema.COLUMNS 
      WHERE TABLE_SCHEMA = 'whr' 
        AND (COLUMN_NAME LIKE '%g_id%' 
             OR COLUMN_NAME LIKE '%gate%' 
             OR COLUMN_NAME LIKE '%reader%' 
             OR COLUMN_NAME LIKE '%equip%'
             OR COLUMN_NAME LIKE '%eqcode%')
    `);
    console.table(mappingCols);

    // 5. 게이트 명칭이 들어있을 만한 테이블 조회
    const candidateTables = tableNames.filter(name => 
      /gate|reader|equip|device|code|common/i.test(name)
    );
    console.log('\n[5] 후보 테이블 데이터 샘플링:', candidateTables.join(', '));
    for (const table of candidateTables) {
      try {
        const [countRes] = await connection.execute(`SELECT COUNT(*) as cnt FROM ??`, [table]);
        console.log(`  - 테이블: ${table} (행 수: ${countRes[0].cnt}개)`);
        if (countRes[0].cnt > 0 && countRes[0].cnt < 1000) {
          const [samples] = await connection.execute(`SELECT * FROM ?? LIMIT 5`, [table]);
          console.log(`    샘플 데이터:`, JSON.stringify(samples, null, 2));
        }
      } catch (e) {
        console.log(`    [-] ${table} 조회 실패:`, e.message);
      }
    }

    await connection.end();
  } catch (err) {
    console.error('[-] 분석 오류:', err.message);
  }
}

runAnalysis();
