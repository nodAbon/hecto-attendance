/**
 * Secom MySQL Column & Table Searcher
 */

const mysql = require('mysql2/promise');

const MYSQL_CONFIG = {
  host: 'Prd-Hecto-WHR-Ext-NLB-8e82b66ed560637d.elb.ap-northeast-2.amazonaws.com',
  user: 'whradmin',
  password: '1q2w3e4r!@#$',
  database: 'whr',
  port: 3306,
  connectTimeout: 5000
};

async function runSearch() {
  console.log('==================================================');
  console.log(' 세콤 MySQL 관련 컬럼/테이블 검색');
  console.log('==================================================');

  try {
    const connection = await mysql.createConnection(MYSQL_CONFIG);
    console.log('[+] MySQL 연결 성공!');

    // 1. 게이트/리더기 관련 컬럼 검색
    console.log('\n[1] gate, reader, equip, device 관련 컬럼 검색:');
    const [gateCols] = await connection.execute(`
      SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE 
      FROM information_schema.COLUMNS 
      WHERE TABLE_SCHEMA = 'whr' 
        AND (COLUMN_NAME LIKE '%gate%' 
             OR COLUMN_NAME LIKE '%reader%' 
             OR COLUMN_NAME LIKE '%equip%' 
             OR COLUMN_NAME LIKE '%dev%')
    `);
    console.table(gateCols);

    // 2. 부서/팀 관련 컬럼 검색
    console.log('\n[2] dept, department, team 관련 컬럼 검색:');
    const [deptCols] = await connection.execute(`
      SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE 
      FROM information_schema.COLUMNS 
      WHERE TABLE_SCHEMA = 'whr' 
        AND (COLUMN_NAME LIKE '%dept%' 
             OR COLUMN_NAME LIKE '%depart%' 
             OR COLUMN_NAME LIKE '%team%')
    `);
    console.table(deptCols);

    // 3. tenter 테이블의 전체 행 수 및 최근 데이터 3건 확인
    console.log('\n[3] tenter 테이블 정보:');
    const [tenterCount] = await connection.execute('SELECT COUNT(*) as cnt FROM tenter');
    console.log(`  - 전체 행 수: ${tenterCount[0].cnt}개`);
    if (tenterCount[0].cnt > 0) {
      const [tenterSamples] = await connection.execute('SELECT * FROM tenter ORDER BY E_DATE DESC, E_TIME DESC LIMIT 3');
      console.log('  - 최근 3건:');
      console.log(JSON.stringify(tenterSamples, null, 2));
    }

    await connection.end();
  } catch (err) {
    console.error('[-] 검색 실패:', err.message);
  }
}

runSearch();
